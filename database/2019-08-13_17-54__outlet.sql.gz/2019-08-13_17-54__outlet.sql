-- MySQL dump 10.16  Distrib 10.1.38-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: outlet
-- ------------------------------------------------------
-- Server version	10.3.13-MariaDB-1:10.3.13+maria~bionic

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_access_log`
--

DROP TABLE IF EXISTS `backend_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_access_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_access_log`
--

LOCK TABLES `backend_access_log` WRITE;
/*!40000 ALTER TABLE `backend_access_log` DISABLE KEYS */;
INSERT INTO `backend_access_log` (`id`, `user_id`, `ip_address`, `created_at`, `updated_at`) VALUES (1,1,'172.16.238.1','2019-08-12 10:43:27','2019-08-12 10:43:27');
/*!40000 ALTER TABLE `backend_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_groups`
--

DROP TABLE IF EXISTS `backend_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_new_user_default` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`),
  KEY `code_index` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_groups`
--

LOCK TABLES `backend_user_groups` WRITE;
/*!40000 ALTER TABLE `backend_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_preferences`
--

DROP TABLE IF EXISTS `backend_user_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_preferences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_item_index` (`user_id`,`namespace`,`group`,`item`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_preferences`
--

LOCK TABLES `backend_user_preferences` WRITE;
/*!40000 ALTER TABLE `backend_user_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_roles`
--

DROP TABLE IF EXISTS `backend_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_unique` (`name`),
  KEY `role_code_index` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_roles`
--

LOCK TABLES `backend_user_roles` WRITE;
/*!40000 ALTER TABLE `backend_user_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_user_throttle`
--

DROP TABLE IF EXISTS `backend_user_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_user_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backend_user_throttle_user_id_index` (`user_id`),
  KEY `backend_user_throttle_ip_address_index` (`ip_address`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_user_throttle`
--

LOCK TABLES `backend_user_throttle` WRITE;
/*!40000 ALTER TABLE `backend_user_throttle` DISABLE KEYS */;
INSERT INTO `backend_user_throttle` (`id`, `user_id`, `ip_address`, `attempts`, `last_attempt_at`, `is_suspended`, `suspended_at`, `is_banned`, `banned_at`) VALUES (1,1,'172.16.238.1',0,NULL,0,NULL,0,NULL);
/*!40000 ALTER TABLE `backend_user_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_users`
--

DROP TABLE IF EXISTS `backend_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `role_id` int(10) unsigned DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_unique` (`login`),
  UNIQUE KEY `email_unique` (`email`),
  KEY `act_code_index` (`activation_code`),
  KEY `reset_code_index` (`reset_password_code`),
  KEY `admin_role_index` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_users`
--

LOCK TABLES `backend_users` WRITE;
/*!40000 ALTER TABLE `backend_users` DISABLE KEYS */;
INSERT INTO `backend_users` (`id`, `first_name`, `last_name`, `login`, `email`, `password`, `activation_code`, `persist_code`, `reset_password_code`, `permissions`, `is_activated`, `role_id`, `activated_at`, `last_login`, `created_at`, `updated_at`, `deleted_at`, `is_superuser`) VALUES (1,'Admin','Person','admin','stefan@lzo.ro','$2y$10$bm5vnsItvVT7R2NE1Bcy5u3Jl3eGnmwwILu9DBTEpwpnI4ZUerOXK',NULL,'$2y$10$qYvK27IE/7KLOVaCAsWzdeoUpH3E/qDunTn3scEK5BmmCGa69QFZO',NULL,'',1,3,NULL,'2019-08-12 10:43:27','2017-06-11 15:36:58','2019-08-12 10:43:27',NULL,1);
/*!40000 ALTER TABLE `backend_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backend_users_groups`
--

DROP TABLE IF EXISTS `backend_users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_users_groups`
--

LOCK TABLES `backend_users_groups` WRITE;
/*!40000 ALTER TABLE `backend_users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_data`
--

DROP TABLE IF EXISTS `cms_theme_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_data_theme_index` (`theme`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_data`
--

LOCK TABLES `cms_theme_data` WRITE;
/*!40000 ALTER TABLE `cms_theme_data` DISABLE KEYS */;
INSERT INTO `cms_theme_data` (`id`, `theme`, `data`, `created_at`, `updated_at`) VALUES (1,'lovata-bootstrap-shopaholic','{\"site_name\":\"Cel mai mare outlet de geci din Romania\",\"company_name\":\"Sc OutletGeci SRL\",\"company_description\":\"Firma noastra este cel mai mare outlet de geci din romania\",\"contact_phone\":\"447440558662\",\"contact_address\":\"Strada grivitei\",\"contact_email\":\"stefan@lzomedia.ro\",\"copyright\":\"Lzo Media\",\"facebook_link\":\"\",\"instagram_link\":\"\",\"twitter_link\":\"\",\"main_slider\":\"[{\\\"title\\\":\\\"Outlet Geci\\\",\\\"image\\\":\\\"\\\\\\/cropped-images\\\\\\/2276408-1-aimplw-0-0-0-0-1565624127.jpg\\\",\\\"link\\\":\\\"\\\",\\\"link_name\\\":\\\"\\\",\\\"description\\\":\\\"Vrei sa gasesti cele mai multe geci \\\"}]\",\"promo_block_left\":\"\",\"promo_block_middle\":\"\",\"promo_block_right\":\"\",\"index_banner\":\"\",\"index_banner_link\":\"\",\"category_left\":\"\",\"category_middle\":\"\",\"category_right\":\"\"}','2019-08-12 15:25:49','2019-08-12 15:38:20');
/*!40000 ALTER TABLE `cms_theme_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_logs`
--

DROP TABLE IF EXISTS `cms_theme_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_content` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_logs_type_index` (`type`),
  KEY `cms_theme_logs_theme_index` (`theme`),
  KEY `cms_theme_logs_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_logs`
--

LOCK TABLES `cms_theme_logs` WRITE;
/*!40000 ALTER TABLE `cms_theme_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_theme_templates`
--

DROP TABLE IF EXISTS `cms_theme_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_theme_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(10) unsigned NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cms_theme_templates_source_index` (`source`),
  KEY `cms_theme_templates_path_index` (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_theme_templates`
--

LOCK TABLES `cms_theme_templates` WRITE;
/*!40000 ALTER TABLE `cms_theme_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_theme_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deferred_bindings`
--

DROP TABLE IF EXISTS `deferred_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deferred_bindings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `master_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `master_field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_bind` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deferred_bindings_master_type_index` (`master_type`),
  KEY `deferred_bindings_master_field_index` (`master_field`),
  KEY `deferred_bindings_slave_type_index` (`slave_type`),
  KEY `deferred_bindings_slave_id_index` (`slave_id`),
  KEY `deferred_bindings_session_key_index` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deferred_bindings`
--

LOCK TABLES `deferred_bindings` WRITE;
/*!40000 ALTER TABLE `deferred_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `deferred_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_addition_properties`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_addition_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_addition_properties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'input',
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_addition_properties_name_index` (`name`),
  KEY `lovata_orders_shopaholic_addition_properties_slug_index` (`slug`),
  KEY `lovata_orders_shopaholic_addition_properties_code_index` (`code`),
  KEY `lovata_orders_shopaholic_addition_properties_sort_order_index` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_addition_properties`
--

LOCK TABLES `lovata_orders_shopaholic_addition_properties` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_addition_properties` DISABLE KEYS */;
INSERT INTO `lovata_orders_shopaholic_addition_properties` (`id`, `active`, `name`, `slug`, `code`, `description`, `type`, `settings`, `sort_order`, `created_at`, `updated_at`) VALUES (1,1,'lovata.toolbox::lang.field.email','email','email',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.field.user\"}',1,'2019-08-12 11:02:19','2019-08-12 11:02:19'),(2,1,'lovata.ordersshopaholic::lang.field.name','name','name',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.field.user\"}',2,'2019-08-12 11:02:19','2019-08-12 11:02:19'),(3,1,'lovata.ordersshopaholic::lang.field.last_name','last_name','last_name',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.field.user\"}',3,'2019-08-12 11:02:19','2019-08-12 11:02:19'),(4,1,'lovata.toolbox::lang.field.phone','phone','phone',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.field.user\"}',4,'2019-08-12 11:02:19','2019-08-12 11:02:19'),(5,1,'lovata.toolbox::lang.field.country','billing_country','billing_country',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',5,'2019-08-12 11:02:26','2019-08-12 11:02:26'),(6,1,'lovata.toolbox::lang.field.state','billing_state','billing_state',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',6,'2019-08-12 11:02:26','2019-08-12 11:02:26'),(7,1,'lovata.toolbox::lang.field.city','billing_city','billing_city',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',7,'2019-08-12 11:02:26','2019-08-12 11:02:27'),(8,1,'lovata.toolbox::lang.field.street','billing_street','billing_street',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',8,'2019-08-12 11:02:27','2019-08-12 11:02:27'),(9,1,'lovata.toolbox::lang.field.house','billing_house','billing_house',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',9,'2019-08-12 11:02:27','2019-08-12 11:02:27'),(10,1,'lovata.toolbox::lang.field.flat','billing_flat','billing_flat',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',10,'2019-08-12 11:02:27','2019-08-12 11:02:27'),(11,1,'lovata.toolbox::lang.field.address1','billing_address1','billing_address1',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',11,'2019-08-12 11:02:28','2019-08-12 11:02:28'),(12,1,'lovata.toolbox::lang.field.address2','billing_address2','billing_address2',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',12,'2019-08-12 11:02:28','2019-08-12 11:02:28'),(13,1,'lovata.toolbox::lang.field.postcode','billing_postcode','billing_postcode',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.billing_address\"}',13,'2019-08-12 11:02:28','2019-08-12 11:02:28'),(14,1,'lovata.toolbox::lang.field.country','shipping_country','shipping_country',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',14,'2019-08-12 11:02:28','2019-08-12 11:02:29'),(15,1,'lovata.toolbox::lang.field.state','shipping_state','shipping_state',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',15,'2019-08-12 11:02:29','2019-08-12 11:02:29'),(16,1,'lovata.toolbox::lang.field.city','shipping_city','shipping_city',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',16,'2019-08-12 11:02:29','2019-08-12 11:02:29'),(17,1,'lovata.toolbox::lang.field.street','shipping_street','shipping_street',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',17,'2019-08-12 11:02:29','2019-08-12 11:02:29'),(18,1,'lovata.toolbox::lang.field.house','shipping_house','shipping_house',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',18,'2019-08-12 11:02:30','2019-08-12 11:02:30'),(19,1,'lovata.toolbox::lang.field.flat','shipping_flat','shipping_flat',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',19,'2019-08-12 11:02:30','2019-08-12 11:02:30'),(20,1,'lovata.toolbox::lang.field.address1','shipping_address1','shipping_address1',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',20,'2019-08-12 11:02:30','2019-08-12 11:02:30'),(21,1,'lovata.toolbox::lang.field.address2','shipping_address2','shipping_address2',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',21,'2019-08-12 11:02:30','2019-08-12 11:02:31'),(22,1,'lovata.toolbox::lang.field.postcode','shipping_postcode','shipping_postcode',NULL,'input','{\"tab\":\"lovata.ordersshopaholic::lang.tab.shipping_address\"}',22,'2019-08-12 11:02:31','2019-08-12 11:02:31');
/*!40000 ALTER TABLE `lovata_orders_shopaholic_addition_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_cart_positions`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_cart_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_cart_positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` int(10) unsigned NOT NULL DEFAULT 0,
  `item_id` int(10) unsigned NOT NULL DEFAULT 0,
  `item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'LovataShopaholicModelsOffer',
  `quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_cart_positions_cart_id_index` (`cart_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_cart_positions`
--

LOCK TABLES `lovata_orders_shopaholic_cart_positions` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_cart_positions` DISABLE KEYS */;
INSERT INTO `lovata_orders_shopaholic_cart_positions` (`id`, `cart_id`, `item_id`, `item_type`, `quantity`, `property`, `created_at`, `updated_at`, `deleted_at`) VALUES (1,1,5,'Lovata\\Shopaholic\\Models\\Offer',1,NULL,'2019-08-12 15:34:10','2019-08-12 16:05:45',NULL);
/*!40000 ALTER TABLE `lovata_orders_shopaholic_cart_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_carts`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_carts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `shipping_type_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_carts_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_carts`
--

LOCK TABLES `lovata_orders_shopaholic_carts` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_carts` DISABLE KEYS */;
INSERT INTO `lovata_orders_shopaholic_carts` (`id`, `user_id`, `created_at`, `updated_at`, `shipping_type_id`, `payment_method_id`, `email`, `user_data`, `property`, `shipping_address`, `billing_address`) VALUES (1,NULL,'2019-08-12 12:04:15','2019-08-12 12:04:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lovata_orders_shopaholic_carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_order_positions`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_order_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_order_positions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `old_price` decimal(15,2) DEFAULT NULL,
  `quantity` int(10) unsigned DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tax_percent` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_order_positions_item_id_index` (`item_id`),
  KEY `lovata_orders_shopaholic_order_positions_item_type_index` (`item_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_order_positions`
--

LOCK TABLES `lovata_orders_shopaholic_order_positions` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_order_positions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_order_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_order_promo_mechanism`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_order_promo_mechanism`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_order_promo_mechanism` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `mechanism_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int(10) unsigned NOT NULL,
  `discount_value` double(8,2) unsigned NOT NULL,
  `discount_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `final_discount` tinyint(1) NOT NULL DEFAULT 0,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `element_id` int(10) unsigned DEFAULT NULL,
  `element_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `element_data` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_order_promo_mechanism`
--

LOCK TABLES `lovata_orders_shopaholic_order_promo_mechanism` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_order_promo_mechanism` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_order_promo_mechanism` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_orders`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `order_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_price` decimal(15,2) DEFAULT NULL,
  `shipping_type_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `property` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_data` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_response` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `shipping_tax_percent` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_orders_user_id_index` (`user_id`),
  KEY `lovata_orders_shopaholic_orders_status_id_index` (`status_id`),
  KEY `lovata_orders_shopaholic_orders_order_number_index` (`order_number`),
  KEY `lovata_orders_shopaholic_orders_shipping_type_id_index` (`shipping_type_id`),
  KEY `lovata_orders_shopaholic_orders_payment_method_id_index` (`payment_method_id`),
  KEY `lovata_orders_shopaholic_orders_currency_id_index` (`currency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_orders`
--

LOCK TABLES `lovata_orders_shopaholic_orders` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_payment_methods`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_payment_methods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cancel_status_id` int(11) DEFAULT 0,
  `fail_status_id` int(11) DEFAULT 0,
  `send_purchase_request` tinyint(1) NOT NULL DEFAULT 0,
  `gateway_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `before_status_id` int(11) DEFAULT 0,
  `after_status_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_payment_methods_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_payment_methods`
--

LOCK TABLES `lovata_orders_shopaholic_payment_methods` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_payment_methods` DISABLE KEYS */;
INSERT INTO `lovata_orders_shopaholic_payment_methods` (`id`, `active`, `name`, `code`, `sort_order`, `preview_text`, `created_at`, `updated_at`, `cancel_status_id`, `fail_status_id`, `send_purchase_request`, `gateway_id`, `gateway_currency`, `gateway_property`, `before_status_id`, `after_status_id`) VALUES (1,1,'La livrare','livrare',1,'','2019-08-12 11:06:03','2019-08-12 11:06:03',0,0,0,NULL,NULL,NULL,0,0);
/*!40000 ALTER TABLE `lovata_orders_shopaholic_payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_position_properties`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_position_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_position_properties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'input',
  `settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_position_properties_name_index` (`name`),
  KEY `lovata_orders_shopaholic_position_properties_slug_index` (`slug`),
  KEY `lovata_orders_shopaholic_position_properties_code_index` (`code`),
  KEY `lovata_orders_shopaholic_position_properties_sort_order_index` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_position_properties`
--

LOCK TABLES `lovata_orders_shopaholic_position_properties` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_position_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_position_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_promo_mechanism`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_promo_mechanism`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_promo_mechanism` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int(10) unsigned NOT NULL,
  `discount_value` double(8,2) unsigned NOT NULL,
  `discount_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `final_discount` tinyint(1) NOT NULL DEFAULT 0,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_promo_mechanism`
--

LOCK TABLES `lovata_orders_shopaholic_promo_mechanism` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_promo_mechanism` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_promo_mechanism` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_shipping_types`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_shipping_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_shipping_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_shipping_types_code_index` (`code`),
  KEY `lovata_orders_shopaholic_shipping_types_sort_order_index` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_shipping_types`
--

LOCK TABLES `lovata_orders_shopaholic_shipping_types` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_shipping_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_shipping_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_statuses`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_user_show` tinyint(1) NOT NULL DEFAULT 0,
  `user_status_id` int(11) DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_statuses_code_index` (`code`),
  KEY `lovata_orders_shopaholic_statuses_sort_order_index` (`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_statuses`
--

LOCK TABLES `lovata_orders_shopaholic_statuses` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_statuses` DISABLE KEYS */;
INSERT INTO `lovata_orders_shopaholic_statuses` (`id`, `name`, `code`, `sort_order`, `created_at`, `updated_at`, `is_user_show`, `user_status_id`, `preview_text`) VALUES (1,'New','new',1,'2019-08-12 11:02:17','2019-08-12 11:02:17',0,NULL,NULL),(2,'In progress','in_progress',2,'2019-08-12 11:02:17','2019-08-12 11:02:17',0,NULL,NULL),(3,'Complete','complete',3,'2019-08-12 11:02:17','2019-08-12 11:02:17',0,NULL,NULL),(4,'Canceled','canceled',4,'2019-08-12 11:02:17','2019-08-12 11:02:17',0,NULL,NULL);
/*!40000 ALTER TABLE `lovata_orders_shopaholic_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_tasks`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mail_template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `manager_id` int(10) unsigned DEFAULT NULL,
  `author_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_tasks_status_index` (`status`),
  KEY `lovata_orders_shopaholic_tasks_order_id_index` (`order_id`),
  KEY `lovata_orders_shopaholic_tasks_user_id_index` (`user_id`),
  KEY `lovata_orders_shopaholic_tasks_manager_id_index` (`manager_id`),
  KEY `lovata_orders_shopaholic_tasks_author_id_index` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_tasks`
--

LOCK TABLES `lovata_orders_shopaholic_tasks` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_orders_shopaholic_user_addresses`
--

DROP TABLE IF EXISTS `lovata_orders_shopaholic_user_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_orders_shopaholic_user_addresses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `house` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `building` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `address1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_orders_shopaholic_user_addresses_user_id_index` (`user_id`),
  KEY `lovata_orders_shopaholic_user_addresses_type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_orders_shopaholic_user_addresses`
--

LOCK TABLES `lovata_orders_shopaholic_user_addresses` WRITE;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_user_addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_orders_shopaholic_user_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_ordersshopaholic_payment_restrictions`
--

DROP TABLE IF EXISTS `lovata_ordersshopaholic_payment_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_ordersshopaholic_payment_restrictions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restriction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_ordersshopaholic_payment_restrictions_code_index` (`code`),
  KEY `lovata_ordersshopaholic_payment_restrictions_restriction_index` (`restriction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_ordersshopaholic_payment_restrictions`
--

LOCK TABLES `lovata_ordersshopaholic_payment_restrictions` WRITE;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_payment_restrictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_payment_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_ordersshopaholic_payment_restrictions_link`
--

DROP TABLE IF EXISTS `lovata_ordersshopaholic_payment_restrictions_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_ordersshopaholic_payment_restrictions_link` (
  `payment_method_id` int(10) unsigned NOT NULL,
  `payment_restriction_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`payment_method_id`,`payment_restriction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_ordersshopaholic_payment_restrictions_link`
--

LOCK TABLES `lovata_ordersshopaholic_payment_restrictions_link` WRITE;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_payment_restrictions_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_payment_restrictions_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_ordersshopaholic_shipping_restrictions`
--

DROP TABLE IF EXISTS `lovata_ordersshopaholic_shipping_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_ordersshopaholic_shipping_restrictions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `restriction` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_ordersshopaholic_shipping_restrictions_code_index` (`code`),
  KEY `lovata_ordersshopaholic_shipping_restrictions_restriction_index` (`restriction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_ordersshopaholic_shipping_restrictions`
--

LOCK TABLES `lovata_ordersshopaholic_shipping_restrictions` WRITE;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_shipping_restrictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_shipping_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_ordersshopaholic_shipping_restrictions_link`
--

DROP TABLE IF EXISTS `lovata_ordersshopaholic_shipping_restrictions_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_ordersshopaholic_shipping_restrictions_link` (
  `shipping_type_id` int(10) unsigned NOT NULL,
  `shipping_restriction_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`shipping_type_id`,`shipping_restriction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_ordersshopaholic_shipping_restrictions_link`
--

LOCK TABLES `lovata_ordersshopaholic_shipping_restrictions_link` WRITE;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_shipping_restrictions_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_ordersshopaholic_shipping_restrictions_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_additional_categories`
--

DROP TABLE IF EXISTS `lovata_shopaholic_additional_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_additional_categories` (
  `category_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`category_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_additional_categories`
--

LOCK TABLES `lovata_shopaholic_additional_categories` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_additional_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_additional_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_brands`
--

DROP TABLE IF EXISTS `lovata_shopaholic_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lovata_shopaholic_brands_slug_unique` (`slug`),
  KEY `lovata_shopaholic_brands_name_index` (`name`),
  KEY `lovata_shopaholic_brands_slug_index` (`slug`),
  KEY `lovata_shopaholic_brands_code_index` (`code`),
  KEY `lovata_shopaholic_brands_external_id_index` (`external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_brands`
--

LOCK TABLES `lovata_shopaholic_brands` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_categories`
--

DROP TABLE IF EXISTS `lovata_shopaholic_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `nest_left` int(10) unsigned DEFAULT NULL,
  `nest_right` int(10) unsigned DEFAULT NULL,
  `nest_depth` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lovata_shopaholic_categories_slug_unique` (`slug`),
  KEY `lovata_shopaholic_categories_name_index` (`name`),
  KEY `lovata_shopaholic_categories_slug_index` (`slug`),
  KEY `lovata_shopaholic_categories_code_index` (`code`),
  KEY `lovata_shopaholic_categories_external_id_index` (`external_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_categories`
--

LOCK TABLES `lovata_shopaholic_categories` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_categories` DISABLE KEYS */;
INSERT INTO `lovata_shopaholic_categories` (`id`, `active`, `name`, `slug`, `code`, `external_id`, `preview_text`, `description`, `parent_id`, `nest_left`, `nest_right`, `nest_depth`, `created_at`, `updated_at`) VALUES (1,1,'Barbati','barbati','OUTLETB','','','',NULL,1,2,0,'2019-08-12 10:51:34','2019-08-12 10:51:34'),(2,1,'Femei','femei','OutletF','','','',NULL,3,4,0,'2019-08-12 10:52:18','2019-08-12 10:52:18');
/*!40000 ALTER TABLE `lovata_shopaholic_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_currency`
--

DROP TABLE IF EXISTS `lovata_shopaholic_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_currency` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(8,2) NOT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lovata_shopaholic_currency_code_unique` (`code`),
  KEY `lovata_shopaholic_currency_code_index` (`code`),
  KEY `lovata_shopaholic_currency_external_id_index` (`external_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_currency`
--

LOCK TABLES `lovata_shopaholic_currency` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_currency` DISABLE KEYS */;
INSERT INTO `lovata_shopaholic_currency` (`id`, `active`, `is_default`, `name`, `code`, `symbol`, `rate`, `external_id`, `sort_order`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,1,'RON','RON','lei',1.00,'',1,NULL,'2019-08-12 10:45:46','2019-08-12 11:01:12');
/*!40000 ALTER TABLE `lovata_shopaholic_currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_offers`
--

DROP TABLE IF EXISTS `lovata_shopaholic_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_offers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `product_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_shopaholic_offers_name_index` (`name`),
  KEY `lovata_shopaholic_offers_code_index` (`code`),
  KEY `lovata_shopaholic_offers_external_id_index` (`external_id`),
  KEY `lovata_shopaholic_offers_product_id_index` (`product_id`),
  KEY `lovata_shopaholic_offers_quantity_index` (`quantity`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_offers`
--

LOCK TABLES `lovata_shopaholic_offers` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_offers` DISABLE KEYS */;
INSERT INTO `lovata_shopaholic_offers` (`id`, `active`, `product_id`, `name`, `code`, `external_id`, `quantity`, `preview_text`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,NULL,'Geaca Barbati Parka din Bumbac L Neagra','D3MYHLBBM','51',0,NULL,NULL,NULL,'2019-08-12 18:06:38','2019-08-12 18:06:38'),(2,1,NULL,'Jack&Jones, Jacheta de piele ecologica Brisbane, Negru','DG8JD5BBM','1',0,NULL,NULL,NULL,'2019-08-12 18:06:40','2019-08-12 18:06:40'),(3,1,NULL,'Zee Lane Denim, Jacheta cu vatelina si gluga, Verde militar','D3KKF0BBM','2',0,NULL,NULL,NULL,'2019-08-12 18:06:43','2019-08-12 18:06:43'),(4,1,NULL,'Geaca blugi barbati - Urban Classics, albastru denim, M EU','DCH8RLBBM','3',0,NULL,NULL,NULL,'2019-08-12 18:06:45','2019-08-12 18:06:45'),(5,1,NULL,'Bomber, Negru','DVPS4NBBM','4',0,NULL,NULL,NULL,'2019-08-12 18:06:47','2019-08-12 18:06:47'),(6,1,NULL,'The North Face, Jacheta usoara cu gluga Thermoball, S, Negru','DBT4QSBBM','5',0,NULL,NULL,NULL,'2019-08-12 18:06:50','2019-08-12 18:06:50'),(7,1,NULL,'Zee Lane Collection, Geaca cu vatelina, Negru','DJGZB0BBM','6',0,NULL,NULL,NULL,'2019-08-12 18:06:52','2019-08-12 18:06:52'),(8,1,NULL,'Geaca fas barbati MALEXXIUS Perseus Neagra marimea XL','DVX9DHBBM','7',0,NULL,NULL,NULL,'2019-08-12 18:06:54','2019-08-12 18:06:54'),(9,1,NULL,'Hummel, Geaca impermeabila Icon, Bleumarin inchis','D5XH3VBBM','8',0,NULL,NULL,NULL,'2019-08-12 18:06:57','2019-08-12 18:06:57'),(10,1,NULL,'Jacheta tip Blugi Western jacket Kam Jeanswear Indigo 5XL','D3N91HBBM','9',0,NULL,NULL,NULL,'2019-08-12 18:06:59','2019-08-12 18:06:59');
/*!40000 ALTER TABLE `lovata_shopaholic_offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_price_types`
--

DROP TABLE IF EXISTS `lovata_shopaholic_price_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_price_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_id` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_shopaholic_price_types_code_index` (`code`),
  KEY `lovata_shopaholic_price_types_external_id_index` (`external_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_price_types`
--

LOCK TABLES `lovata_shopaholic_price_types` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_price_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_price_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_prices`
--

DROP TABLE IF EXISTS `lovata_shopaholic_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `item_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `old_price` decimal(15,2) DEFAULT NULL,
  `price_type_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lovata_shopaholic_prices_item_id_index` (`item_id`),
  KEY `lovata_shopaholic_prices_item_type_index` (`item_type`),
  KEY `lovata_shopaholic_prices_price_index` (`price`),
  KEY `lovata_shopaholic_prices_old_price_index` (`old_price`),
  KEY `lovata_shopaholic_prices_price_type_id_index` (`price_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_prices`
--

LOCK TABLES `lovata_shopaholic_prices` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_prices` DISABLE KEYS */;
INSERT INTO `lovata_shopaholic_prices` (`id`, `item_id`, `item_type`, `price`, `old_price`, `price_type_id`, `created_at`, `updated_at`) VALUES (1,1,'Lovata\\Shopaholic\\Models\\Offer',199.99,199.99,NULL,'2019-08-12 18:06:39','2019-08-12 18:06:39'),(2,2,'Lovata\\Shopaholic\\Models\\Offer',599.99,599.99,NULL,'2019-08-12 18:06:41','2019-08-12 18:06:41'),(3,3,'Lovata\\Shopaholic\\Models\\Offer',169.99,479.99,NULL,'2019-08-12 18:06:43','2019-08-12 18:06:43'),(4,4,'Lovata\\Shopaholic\\Models\\Offer',282.00,449.00,NULL,'2019-08-12 18:06:45','2019-08-12 18:06:45'),(5,5,'Lovata\\Shopaholic\\Models\\Offer',99.99,350.00,NULL,'2019-08-12 18:06:48','2019-08-12 18:06:48'),(6,6,'Lovata\\Shopaholic\\Models\\Offer',679.99,1179.99,NULL,'2019-08-12 18:06:50','2019-08-12 18:06:50'),(7,7,'Lovata\\Shopaholic\\Models\\Offer',99.99,369.99,NULL,'2019-08-12 18:06:52','2019-08-12 18:06:52'),(8,8,'Lovata\\Shopaholic\\Models\\Offer',99.99,149.99,NULL,'2019-08-12 18:06:55','2019-08-12 18:06:55'),(9,9,'Lovata\\Shopaholic\\Models\\Offer',179.99,489.99,NULL,'2019-08-12 18:06:57','2019-08-12 18:06:57');
/*!40000 ALTER TABLE `lovata_shopaholic_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_products`
--

DROP TABLE IF EXISTS `lovata_shopaholic_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lovata_shopaholic_products_slug_unique` (`slug`),
  KEY `lovata_shopaholic_products_name_index` (`name`),
  KEY `lovata_shopaholic_products_slug_index` (`slug`),
  KEY `lovata_shopaholic_products_code_index` (`code`),
  KEY `lovata_shopaholic_products_external_id_index` (`external_id`),
  KEY `lovata_shopaholic_products_brand_id_index` (`brand_id`),
  KEY `lovata_shopaholic_products_category_id_index` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_products`
--

LOCK TABLES `lovata_shopaholic_products` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_products` DISABLE KEYS */;
INSERT INTO `lovata_shopaholic_products` (`id`, `active`, `name`, `slug`, `brand_id`, `category_id`, `external_id`, `code`, `preview_text`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,'Jack&Jones, Jacheta de piele ecologica Brisbane, Negru','jackjones-jacheta-de-piele-ecologica-brisbane-negru',NULL,NULL,'24206565','eMAG',NULL,NULL,NULL,'2019-08-12 18:06:40','2019-08-12 18:06:40'),(2,1,'Zee Lane Denim, Jacheta cu vatelina si gluga, Verde militar','zee-lane-denim-jacheta-cu-vatelina-si-gluga-verde-militar',NULL,NULL,'9690014','eMAG',NULL,NULL,NULL,'2019-08-12 18:06:42','2019-08-12 18:06:42'),(3,1,'Geaca blugi barbati - Urban Classics, albastru denim, M EU','geaca-blugi-barbati-urban-classics-albastru-denim-m-eu',NULL,NULL,'20165985','HighMag',NULL,NULL,NULL,'2019-08-12 18:06:44','2019-08-12 18:06:44'),(4,1,'Bomber, Negru','bomber-negru',NULL,NULL,'8894445','GLOBAL ALL AROUND SRL',NULL,NULL,NULL,'2019-08-12 18:06:47','2019-08-12 18:06:47'),(5,1,'The North Face, Jacheta usoara cu gluga Thermoball, S, Negru','the-north-face-jacheta-usoara-cu-gluga-thermoball-s-negru',NULL,NULL,'16433317','eMAG',NULL,NULL,NULL,'2019-08-12 18:06:49','2019-08-12 18:06:49'),(6,1,'Zee Lane Collection, Geaca cu vatelina, Negru','zee-lane-collection-geaca-cu-vatelina-negru',NULL,NULL,'9257267','eMAG',NULL,NULL,NULL,'2019-08-12 18:06:51','2019-08-12 18:06:51'),(7,1,'Geaca fas barbati MALEXXIUS Perseus Neagra marimea XL','geaca-fas-barbati-malexxius-perseus-neagra-marimea-xl',NULL,NULL,'10351352','OutletSea',NULL,NULL,NULL,'2019-08-12 18:06:54','2019-08-12 18:06:54'),(8,1,'Hummel, Geaca impermeabila Icon, Bleumarin inchis','hummel-geaca-impermeabila-icon-bleumarin-inchis',NULL,NULL,'16723751','eMAG',NULL,NULL,NULL,'2019-08-12 18:06:56','2019-08-12 18:06:56'),(9,1,'Jacheta tip Blugi Western jacket Kam Jeanswear Indigo 5XL','jacheta-tip-blugi-western-jacket-kam-jeanswear-indigo-5xl',NULL,NULL,'10857660','KIing Size Outside',NULL,NULL,NULL,'2019-08-12 18:06:59','2019-08-12 18:06:59');
/*!40000 ALTER TABLE `lovata_shopaholic_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_promo_block`
--

DROP TABLE IF EXISTS `lovata_shopaholic_promo_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_promo_block` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `hidden` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_begin` datetime NOT NULL,
  `date_end` datetime DEFAULT NULL,
  `preview_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lovata_shopaholic_promo_block_slug_unique` (`slug`),
  KEY `lovata_shopaholic_promo_block_name_index` (`name`),
  KEY `lovata_shopaholic_promo_block_slug_index` (`slug`),
  KEY `lovata_shopaholic_promo_block_code_index` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_promo_block`
--

LOCK TABLES `lovata_shopaholic_promo_block` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_promo_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_promo_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_promo_block_relation`
--

DROP TABLE IF EXISTS `lovata_shopaholic_promo_block_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_promo_block_relation` (
  `promo_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`promo_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_promo_block_relation`
--

LOCK TABLES `lovata_shopaholic_promo_block_relation` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_promo_block_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_promo_block_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_tax_category_link`
--

DROP TABLE IF EXISTS `lovata_shopaholic_tax_category_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_tax_category_link` (
  `tax_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`category_id`,`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_tax_category_link`
--

LOCK TABLES `lovata_shopaholic_tax_category_link` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_category_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_category_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_tax_country_link`
--

DROP TABLE IF EXISTS `lovata_shopaholic_tax_country_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_tax_country_link` (
  `tax_id` int(10) unsigned NOT NULL,
  `country_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`country_id`,`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_tax_country_link`
--

LOCK TABLES `lovata_shopaholic_tax_country_link` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_country_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_country_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_tax_product_link`
--

DROP TABLE IF EXISTS `lovata_shopaholic_tax_product_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_tax_product_link` (
  `tax_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`product_id`,`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_tax_product_link`
--

LOCK TABLES `lovata_shopaholic_tax_product_link` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_product_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_product_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_tax_state_link`
--

DROP TABLE IF EXISTS `lovata_shopaholic_tax_state_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_tax_state_link` (
  `tax_id` int(10) unsigned NOT NULL,
  `state_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`state_id`,`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_tax_state_link`
--

LOCK TABLES `lovata_shopaholic_tax_state_link` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_state_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_tax_state_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lovata_shopaholic_taxes`
--

DROP TABLE IF EXISTS `lovata_shopaholic_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lovata_shopaholic_taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `is_global` tinyint(1) NOT NULL DEFAULT 0,
  `percent` decimal(8,2) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `applied_to_shipping_price` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lovata_shopaholic_taxes`
--

LOCK TABLES `lovata_shopaholic_taxes` WRITE;
/*!40000 ALTER TABLE `lovata_shopaholic_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lovata_shopaholic_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2013_10_01_000001_Db_Deferred_Bindings',1),(2,'2013_10_01_000002_Db_System_Files',1),(3,'2013_10_01_000003_Db_System_Plugin_Versions',1),(4,'2013_10_01_000004_Db_System_Plugin_History',1),(5,'2013_10_01_000005_Db_System_Settings',1),(6,'2013_10_01_000006_Db_System_Parameters',1),(7,'2013_10_01_000007_Db_System_Add_Disabled_Flag',1),(8,'2013_10_01_000008_Db_System_Mail_Templates',1),(9,'2013_10_01_000009_Db_System_Mail_Layouts',1),(10,'2014_10_01_000010_Db_Jobs',1),(11,'2014_10_01_000011_Db_System_Event_Logs',1),(12,'2014_10_01_000012_Db_System_Request_Logs',1),(13,'2014_10_01_000013_Db_System_Sessions',1),(14,'2015_10_01_000014_Db_System_Mail_Layout_Rename',1),(15,'2015_10_01_000015_Db_System_Add_Frozen_Flag',1),(16,'2015_10_01_000016_Db_Cache',1),(17,'2015_10_01_000017_Db_System_Revisions',1),(18,'2015_10_01_000018_Db_FailedJobs',1),(19,'2016_10_01_000019_Db_System_Plugin_History_Detail_Text',1),(20,'2016_10_01_000020_Db_System_Timestamp_Fix',1),(21,'2017_08_04_121309_Db_Deferred_Bindings_Add_Index_Session',1),(22,'2017_10_01_000021_Db_System_Sessions_Update',1),(23,'2017_10_01_000022_Db_Jobs_FailedJobs_Update',1),(24,'2017_10_01_000023_Db_System_Mail_Partials',1),(25,'2017_10_23_000024_Db_System_Mail_Layouts_Add_Options_Field',1),(26,'2013_10_01_000001_Db_Backend_Users',2),(27,'2013_10_01_000002_Db_Backend_User_Groups',2),(28,'2013_10_01_000003_Db_Backend_Users_Groups',2),(29,'2013_10_01_000004_Db_Backend_User_Throttle',2),(30,'2014_01_04_000005_Db_Backend_User_Preferences',2),(31,'2014_10_01_000006_Db_Backend_Access_Log',2),(32,'2014_10_01_000007_Db_Backend_Add_Description_Field',2),(33,'2015_10_01_000008_Db_Backend_Add_Superuser_Flag',2),(34,'2016_10_01_000009_Db_Backend_Timestamp_Fix',2),(35,'2017_10_01_000010_Db_Backend_User_Roles',2),(36,'2018_12_16_000011_Db_Backend_Add_Deleted_At',2),(37,'2014_10_01_000001_Db_Cms_Theme_Data',3),(38,'2016_10_01_000002_Db_Cms_Timestamp_Fix',3),(39,'2017_10_01_000003_Db_Cms_Theme_Logs',3),(40,'2018_11_01_000001_Db_Cms_Theme_Templates',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rainlab_user_mail_blockers`
--

DROP TABLE IF EXISTS `rainlab_user_mail_blockers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rainlab_user_mail_blockers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rainlab_user_mail_blockers_email_index` (`email`),
  KEY `rainlab_user_mail_blockers_template_index` (`template`),
  KEY `rainlab_user_mail_blockers_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rainlab_user_mail_blockers`
--

LOCK TABLES `rainlab_user_mail_blockers` WRITE;
/*!40000 ALTER TABLE `rainlab_user_mail_blockers` DISABLE KEYS */;
/*!40000 ALTER TABLE `rainlab_user_mail_blockers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_event_logs`
--

DROP TABLE IF EXISTS `system_event_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_event_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_event_logs_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_event_logs`
--

LOCK TABLES `system_event_logs` WRITE;
/*!40000 ALTER TABLE `system_event_logs` DISABLE KEYS */;
INSERT INTO `system_event_logs` (`id`, `level`, `message`, `details`, `created_at`, `updated_at`) VALUES (1,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 14:50:59','2019-08-12 14:50:59'),(2,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 14:50:59','2019-08-12 14:50:59'),(3,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 14:50:59','2019-08-12 14:50:59'),(4,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 14:50:59','2019-08-12 14:50:59'),(5,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 14:53:44','2019-08-12 14:53:44'),(6,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 14:53:44','2019-08-12 14:53:44'),(7,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 14:53:44','2019-08-12 14:53:44'),(8,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 14:53:44','2019-08-12 14:53:44'),(9,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:18:40','2019-08-12 15:18:40'),(10,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:18:40','2019-08-12 15:18:40'),(11,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:18:40','2019-08-12 15:18:40'),(12,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:18:40','2019-08-12 15:18:40'),(13,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(14,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(15,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(16,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(17,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(18,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(19,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(20,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:19:37','2019-08-12 15:19:37'),(21,'error','ErrorException: Trying to get property \'name\' of non-object in /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php:37\nStack trace:\n#0 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(37): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/shared/httpd/o...\', 37, Array)\n#1 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(53): LzoMedia\\Outlet\\Services\\PricesImporter->getItem()\n#2 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/routes.php(55): LzoMedia\\Outlet\\Services\\PricesImporter->process()\n#3 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(198): System\\Classes\\PluginManager->{closure}()\n#4 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(172): Illuminate\\Routing\\Route->runCallable()\n#5 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#6 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#7 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#8 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#9 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#10 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#11 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#12 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#13 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(24): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#16 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#21 /shared/httpd/outlet/htdocs/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#22 {main}',NULL,'2019-08-12 15:19:41','2019-08-12 15:19:41'),(22,'error','ErrorException: Trying to get property \'name\' of non-object in /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php:37\nStack trace:\n#0 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(37): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/shared/httpd/o...\', 37, Array)\n#1 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(53): LzoMedia\\Outlet\\Services\\PricesImporter->getItem()\n#2 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/routes.php(55): LzoMedia\\Outlet\\Services\\PricesImporter->process()\n#3 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(198): System\\Classes\\PluginManager->{closure}()\n#4 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(172): Illuminate\\Routing\\Route->runCallable()\n#5 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#6 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#7 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#8 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#9 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#10 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#11 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#12 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#13 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(24): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#16 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#21 /shared/httpd/outlet/htdocs/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#22 {main}',NULL,'2019-08-12 15:19:41','2019-08-12 15:19:41'),(23,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:20:22','2019-08-12 15:20:22'),(24,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:20:22','2019-08-12 15:20:22'),(25,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:20:22','2019-08-12 15:20:22'),(26,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:20:22','2019-08-12 15:20:22'),(27,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:21:00','2019-08-12 15:21:00'),(28,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:21:00','2019-08-12 15:21:00'),(29,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:21:00','2019-08-12 15:21:00'),(30,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:21:00','2019-08-12 15:21:00'),(31,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:42:40','2019-08-12 15:42:40'),(32,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:42:40','2019-08-12 15:42:40'),(33,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:42:40','2019-08-12 15:42:40'),(34,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:42:40','2019-08-12 15:42:40'),(35,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:44:34','2019-08-12 15:44:34'),(36,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:44:34','2019-08-12 15:44:34'),(37,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:44:34','2019-08-12 15:44:34'),(38,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:44:35','2019-08-12 15:44:35'),(39,'error','ErrorException: Trying to get property \'id\' of non-object in /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php:37\nStack trace:\n#0 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(37): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/shared/httpd/o...\', 37, Array)\n#1 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(53): LzoMedia\\Outlet\\Services\\PricesImporter->getItem()\n#2 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/routes.php(55): LzoMedia\\Outlet\\Services\\PricesImporter->process()\n#3 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(198): System\\Classes\\PluginManager->{closure}()\n#4 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(172): Illuminate\\Routing\\Route->runCallable()\n#5 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#6 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#7 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#8 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#9 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#10 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#11 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#12 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#13 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(24): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#16 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#21 /shared/httpd/outlet/htdocs/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#22 {main}',NULL,'2019-08-12 15:44:38','2019-08-12 15:44:38'),(40,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:49:26','2019-08-12 15:49:26'),(41,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:49:26','2019-08-12 15:49:26'),(42,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:49:26','2019-08-12 15:49:26'),(43,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:49:27','2019-08-12 15:49:27'),(44,'error','ErrorException: Undefined property: stdClass::$display in /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/ProductsImporter.php:35\nStack trace:\n#0 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/ProductsImporter.php(35): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Undefined prope...\', \'/shared/httpd/o...\', 35, Array)\n#1 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/ProductsImporter.php(47): LzoMedia\\Outlet\\Services\\ProductsImporter->getItem()\n#2 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/routes.php(51): LzoMedia\\Outlet\\Services\\ProductsImporter->process()\n#3 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(198): System\\Classes\\PluginManager->{closure}()\n#4 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(172): Illuminate\\Routing\\Route->runCallable()\n#5 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#6 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#7 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#8 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#9 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#10 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#11 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#12 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#13 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(24): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#16 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#21 /shared/httpd/outlet/htdocs/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#22 {main}',NULL,'2019-08-12 15:49:29','2019-08-12 15:49:29'),(45,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:50:33','2019-08-12 15:50:33'),(46,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:50:33','2019-08-12 15:50:33'),(47,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:50:33','2019-08-12 15:50:33'),(48,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:50:33','2019-08-12 15:50:33'),(49,'error','ErrorException: Trying to get property \'id\' of non-object in /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php:37\nStack trace:\n#0 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(37): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/shared/httpd/o...\', 37, Array)\n#1 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/services/PricesImporter.php(53): LzoMedia\\Outlet\\Services\\PricesImporter->getItem()\n#2 /shared/httpd/outlet/htdocs/plugins/lzomedia/outlet/routes.php(55): LzoMedia\\Outlet\\Services\\PricesImporter->process()\n#3 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(198): System\\Classes\\PluginManager->{closure}()\n#4 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Route.php(172): Illuminate\\Routing\\Route->runCallable()\n#5 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#6 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#7 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#8 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#9 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#10 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#11 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#12 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#13 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /shared/httpd/outlet/htdocs/vendor/october/rain/src/Foundation/Http/Middleware/CheckForMaintenanceMode.php(24): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#16 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): October\\Rain\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /shared/httpd/outlet/htdocs/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#21 /shared/httpd/outlet/htdocs/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#22 {main}',NULL,'2019-08-12 15:50:37','2019-08-12 15:50:37'),(50,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:51:54','2019-08-12 15:51:54'),(51,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:51:54','2019-08-12 15:51:54'),(52,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:51:54','2019-08-12 15:51:54'),(53,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:51:54','2019-08-12 15:51:54'),(54,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:52:46','2019-08-12 15:52:46'),(55,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:52:47','2019-08-12 15:52:47'),(56,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:52:47','2019-08-12 15:52:47'),(57,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:52:47','2019-08-12 15:52:47'),(58,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 15:52:58','2019-08-12 15:52:58'),(59,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 15:52:58','2019-08-12 15:52:58'),(60,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 15:52:58','2019-08-12 15:52:58'),(61,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 15:52:58','2019-08-12 15:52:58'),(62,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 17:53:46','2019-08-12 17:53:46'),(63,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 17:53:46','2019-08-12 17:53:46'),(64,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 17:53:46','2019-08-12 17:53:46'),(65,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 17:53:46','2019-08-12 17:53:46'),(66,'debug','Rejected',NULL,'2019-08-12 17:54:03','2019-08-12 17:54:03'),(67,'debug','Rejected',NULL,'2019-08-12 17:54:03','2019-08-12 17:54:03'),(68,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 17:57:03','2019-08-12 17:57:03'),(69,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 17:57:03','2019-08-12 17:57:03'),(70,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 17:57:04','2019-08-12 17:57:04'),(71,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 17:57:04','2019-08-12 17:57:04'),(72,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 18:02:29','2019-08-12 18:02:29'),(73,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 18:02:29','2019-08-12 18:02:29'),(74,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 18:02:30','2019-08-12 18:02:30'),(75,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 18:02:30','2019-08-12 18:02:30'),(76,'debug','Rejected',NULL,'2019-08-12 18:02:45','2019-08-12 18:02:45'),(77,'debug','Rejected',NULL,'2019-08-12 18:02:46','2019-08-12 18:02:46'),(78,'debug','Rejected',NULL,'2019-08-12 18:02:46','2019-08-12 18:02:46'),(79,'debug','Rejected',NULL,'2019-08-12 18:02:46','2019-08-12 18:02:46'),(80,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 18:03:17','2019-08-12 18:03:17'),(81,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 18:03:17','2019-08-12 18:03:17'),(82,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 18:03:17','2019-08-12 18:03:17'),(83,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 18:03:18','2019-08-12 18:03:18'),(84,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 18:03:53','2019-08-12 18:03:53'),(85,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 18:03:53','2019-08-12 18:03:53'),(86,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 18:03:53','2019-08-12 18:03:53'),(87,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 18:03:53','2019-08-12 18:03:53'),(88,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 18:04:26','2019-08-12 18:04:26'),(89,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 18:04:26','2019-08-12 18:04:26'),(90,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 18:04:26','2019-08-12 18:04:26'),(91,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 18:04:26','2019-08-12 18:04:26'),(92,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 18:06:49','2019-08-12 18:06:49'),(93,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 18:06:49','2019-08-12 18:06:49'),(94,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 18:06:49','2019-08-12 18:06:49'),(95,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 18:06:49','2019-08-12 18:06:49'),(96,'debug','Rejected',NULL,'2019-08-12 18:06:52','2019-08-12 18:06:52'),(97,'debug','Rejected',NULL,'2019-08-12 18:06:52','2019-08-12 18:06:52'),(98,'debug','Rejected',NULL,'2019-08-12 18:06:52','2019-08-12 18:06:52'),(99,'debug','Rejected',NULL,'2019-08-12 18:06:52','2019-08-12 18:06:52'),(100,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p0',NULL,'2019-08-12 18:06:59','2019-08-12 18:06:59'),(101,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p1',NULL,'2019-08-12 18:06:59','2019-08-12 18:06:59'),(102,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p2',NULL,'2019-08-12 18:06:59','2019-08-12 18:06:59'),(103,'debug','https://www.emag.ro/search-by-url?templates[0]=full&is_eab49=false&url=/search/geci-barbati/p3',NULL,'2019-08-12 18:06:59','2019-08-12 18:06:59'),(104,'debug','Rejected',NULL,'2019-08-12 18:07:01','2019-08-12 18:07:01'),(105,'debug','Rejected',NULL,'2019-08-12 18:07:01','2019-08-12 18:07:01'),(106,'debug','Rejected',NULL,'2019-08-12 18:07:01','2019-08-12 18:07:01'),(107,'debug','Rejected',NULL,'2019-08-12 18:07:01','2019-08-12 18:07:01');
/*!40000 ALTER TABLE `system_event_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_files`
--

DROP TABLE IF EXISTS `system_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `disk_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL,
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_files_field_index` (`field`),
  KEY `system_files_attachment_id_index` (`attachment_id`),
  KEY `system_files_attachment_type_index` (`attachment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_files`
--

LOCK TABLES `system_files` WRITE;
/*!40000 ALTER TABLE `system_files` DISABLE KEYS */;
INSERT INTO `system_files` (`id`, `disk_name`, `file_name`, `file_size`, `content_type`, `title`, `description`, `field`, `attachment_id`, `attachment_type`, `is_public`, `sort_order`, `created_at`, `updated_at`) VALUES (1,'5d5186a0c91eb391139091.jpg','2276408 (1)-aimplw.jpg',6850,'image/jpeg',NULL,NULL,'preview_image','1','Lovata\\Shopaholic\\Models\\Product',1,1,'2019-08-12 15:32:48','2019-08-12 15:32:56');
/*!40000 ALTER TABLE `system_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_layouts`
--

DROP TABLE IF EXISTS `system_mail_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_css` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `options` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_layouts`
--

LOCK TABLES `system_mail_layouts` WRITE;
/*!40000 ALTER TABLE `system_mail_layouts` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_mail_layouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_partials`
--

DROP TABLE IF EXISTS `system_mail_partials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_partials` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_partials`
--

LOCK TABLES `system_mail_partials` WRITE;
/*!40000 ALTER TABLE `system_mail_partials` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_mail_partials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_mail_templates`
--

DROP TABLE IF EXISTS `system_mail_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_mail_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_id` int(11) DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_mail_templates_layout_id_index` (`layout_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_mail_templates`
--

LOCK TABLES `system_mail_templates` WRITE;
/*!40000 ALTER TABLE `system_mail_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_mail_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_parameters`
--

DROP TABLE IF EXISTS `system_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_index` (`namespace`,`group`,`item`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_parameters`
--

LOCK TABLES `system_parameters` WRITE;
/*!40000 ALTER TABLE `system_parameters` DISABLE KEYS */;
INSERT INTO `system_parameters` (`id`, `namespace`, `group`, `item`, `value`) VALUES (1,'system','update','count','0'),(2,'system','update','retry','1565693014'),(3,'system','core','build','455'),(4,'system','core','hash','\"530fb2559d6b264485c60ac3797fe8ac\"'),(5,'system','theme','history','{\"Lovata.bootstrap-shopaholic\":\"lovata-bootstrap-shopaholic\"}'),(6,'cms','theme','active','\"lovata-bootstrap-shopaholic\"');
/*!40000 ALTER TABLE `system_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin_history`
--

DROP TABLE IF EXISTS `system_plugin_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_plugin_history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_plugin_history_code_index` (`code`),
  KEY `system_plugin_history_type_index` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=300 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin_history`
--

LOCK TABLES `system_plugin_history` WRITE;
/*!40000 ALTER TABLE `system_plugin_history` DISABLE KEYS */;
INSERT INTO `system_plugin_history` (`id`, `code`, `type`, `version`, `detail`, `created_at`) VALUES (1,'October.Demo','comment','1.0.1','First version of Demo','2019-08-12 10:40:11'),(2,'Lovata.Toolbox','comment','1.0.0','Initialize plugin.','2019-08-12 10:45:31'),(3,'Lovata.Toolbox','comment','1.1.0','Add diff, unshift, push, getNearestNext, getNearestPrev methods to ElementCollection class, add ComponentSubmitForm class','2019-08-12 10:45:31'),(4,'Lovata.Toolbox','comment','1.2.0','Add integration with Translate plugin','2019-08-12 10:45:31'),(5,'Lovata.Toolbox','comment','1.3.0','Adding afterCreate model event handling for additional cache cleaning','2019-08-12 10:45:31'),(6,'Lovata.Toolbox','comment','1.3.1','Restore getOldFormData() method in ComponentSubmitForm class','2019-08-12 10:45:31'),(7,'Lovata.Toolbox','comment','1.3.2','Fix lang path for the default properties tab in CommonProperty class','2019-08-12 10:45:31'),(8,'Lovata.Toolbox','comment','1.3.3','Fix path to field name with error in getErrorMessage() method','2019-08-12 10:45:31'),(9,'Lovata.Toolbox','comment','1.4.0','Add PageHelper class','2019-08-12 10:45:31'),(10,'Lovata.Toolbox','comment','1.4.1','Fix processing of positive results in ComponentSubmitForm::getResponseModeAjax() method, if flash_on enabled','2019-08-12 10:45:31'),(11,'Lovata.Toolbox','comment','1.5.0','Add TraitInitActiveLang trait','2019-08-12 10:45:32'),(12,'Lovata.Toolbox','comment','1.6.0','Add SendMailHelper class, Add CommonSettings model','2019-08-12 10:45:32'),(13,'Lovata.Toolbox','comment','1.7.0','Add UserStorage classes. Add classes for integration with Lovata.Buddies and RainLab.User plugins','2019-08-12 10:45:32'),(14,'Lovata.Toolbox','comment','1.8.0','Added translation into French. Thanks for contribution philmarc.','2019-08-12 10:45:32'),(15,'Lovata.Toolbox','comment','1.9.0','Add TraitCached. Update vendor packages.','2019-08-12 10:45:32'),(16,'Lovata.Toolbox','comment','1.9.1','Remove force boot and register plugins in CommonTest class','2019-08-12 10:45:32'),(17,'Lovata.Toolbox','comment','1.10.0','Add PriceHelperTrait. Move PriceHelper class from Shopaholic plugin. Add set(), applySorting() methods to ElementCollection class. Add abstract store classes.','2019-08-12 10:45:32'),(18,'Lovata.Toolbox','comment','1.10.1','Fix ItemStorage class. Clone item objects form storage.','2019-08-12 10:45:32'),(19,'Lovata.Toolbox','comment','1.10.2','Fix ItemStorage class. Added cloning of *Item object before saving it to storage.','2019-08-12 10:45:32'),(20,'Lovata.Toolbox','comment','1.11.0','Added saving of arrays to class properties of *Store class objects after receiving array from cache.','2019-08-12 10:45:32'),(21,'Lovata.Toolbox','comment','1.12.0','Add PageHelper::getPageNameList() method.','2019-08-12 10:45:33'),(22,'Lovata.Toolbox','comment','1.12.1','Update of vendor packages','2019-08-12 10:45:33'),(23,'Lovata.Toolbox','comment','1.12.2','Update of php-pagination vendor packages','2019-08-12 10:45:33'),(24,'Lovata.Toolbox','comment','1.13.0','Added type returned by methods in AbstractStore * classes','2019-08-12 10:45:33'),(25,'Lovata.Toolbox','comment','1.14.0','Add Countable interface in ElementCollection class','2019-08-12 10:45:33'),(26,'Lovata.Toolbox','comment','1.14.1','Added natsort() for property value variants.','2019-08-12 10:45:33'),(27,'Lovata.Toolbox','comment','1.15.0','Added AbstractBackendColumnHandler, AbstractBackendFieldHandler, AbstractBackendMenuHandler, AbstractExtendRelationConfigHandler, AbstractModelRelationHandler classes.','2019-08-12 10:45:33'),(28,'Lovata.Toolbox','comment','1.16.0','Add package information to composer.json. Thanks for contribution pikanji.','2019-08-12 10:45:33'),(29,'Lovata.Toolbox','comment','1.17.0','Added processing of \"limit\" parameter for the pagination component.','2019-08-12 10:45:33'),(30,'Lovata.Toolbox','comment','1.18.0','Added AbstractImportModel class.','2019-08-12 10:45:34'),(31,'Lovata.Toolbox','comment','1.19.0','Added supported property types: number, rich editor, single checkbox, switch, balloon selector, tag list, radio.','2019-08-12 10:45:34'),(32,'Lovata.Toolbox','comment','1.20.0','Added Japanese language. Thanks for contribution pikanji.','2019-08-12 10:45:34'),(33,'Lovata.Toolbox','comment','1.20.1','Fixed deletion of old images for improt from CSV file.','2019-08-12 10:45:34'),(34,'Lovata.Toolbox','comment','1.21.0','Added support translatable slug in ElementPage class. Added German language. Thanks for contribution Gerald.','2019-08-12 10:45:34'),(35,'Lovata.Toolbox','comment','1.21.1','Removed Iterator interface from ElementCollection class. Added IteratorAggregate interface to ElementCollection class.','2019-08-12 10:45:34'),(36,'Lovata.Toolbox','comment','1.22.0','Replace array_intersect function with array_intersect_key in ElementCollection class.','2019-08-12 10:45:34'),(37,'Lovata.Toolbox','comment','1.23.0','Added copy() method to ElementCollection class. Added choice twig function.','2019-08-12 10:45:34'),(38,'Lovata.Toolbox','comment','1.24.0','Added caching of uploaded file objects as an array.','2019-08-12 10:45:34'),(39,'Lovata.Toolbox','comment','1.24.1','Fixed copy() method in ElementCollection class.','2019-08-12 10:45:34'),(40,'Lovata.Toolbox','comment','1.25.0','Added classes for import elements from xml file.','2019-08-12 10:45:35'),(41,'Lovata.Toolbox','comment','1.25.1','Fixed openMainFile method in AbstractImportModelFromXML class.','2019-08-12 10:45:35'),(42,'Lovata.Toolbox','comment','1.25.2','Added try->catch section for removing images in AbstractImportModel class.','2019-08-12 10:45:35'),(43,'Lovata.Toolbox','comment','1.25.3','Fixed bug with import through queues.','2019-08-12 10:45:35'),(44,'Lovata.Shopaholic','script','1.0.0','create_table_categories.php','2019-08-12 10:45:36'),(45,'Lovata.Shopaholic','script','1.0.0','create_table_products.php','2019-08-12 10:45:37'),(46,'Lovata.Shopaholic','script','1.0.0','create_table_offers.php','2019-08-12 10:45:37'),(47,'Lovata.Shopaholic','script','1.0.0','create_table_brands.php','2019-08-12 10:45:38'),(48,'Lovata.Shopaholic','comment','1.0.0','Initialize plugin.','2019-08-12 10:45:38'),(49,'Lovata.Shopaholic','comment','1.1.0','Add integration with \"Popularity for Shopaholic\" and \"Tags for Shopaholic\" plugins','2019-08-12 10:45:38'),(50,'Lovata.Shopaholic','comment','1.2.0','preview_image, images fields in item classes returns \\System\\Models\\File class objects. Add integration with \"Reviews for Shopaholic\" plugin','2019-08-12 10:45:38'),(51,'Lovata.Shopaholic','comment','1.2.1','Remove php short tags from offers/update.htm','2019-08-12 10:45:38'),(52,'Lovata.Shopaholic','comment','1.2.2','Add additional cache cleaning after category reordering','2019-08-12 10:45:38'),(53,'Lovata.Shopaholic','comment','1.2.3','Adding additional cache cleaning for the sorted list of brands, after the creation of a new brand. Requires Toolbox plugin version 1.3.0 and later.','2019-08-12 10:45:38'),(54,'Lovata.Shopaholic','comment','1.3.0','Add menu types for integration with the StaticPage plugin. Add getPageUrl() method to the CategoryItem class. Requires Toolbox plugin version 1.4.0 and later. Thanks for contribution Alvaro Cánepa.','2019-08-12 10:45:39'),(55,'Lovata.Shopaholic','comment','1.3.1','Fix: processing of the \"nesting\" flag for the menu type \"catalog\"','2019-08-12 10:45:39'),(56,'Lovata.Shopaholic','comment','1.4.0','Replace code of product sorting by popularity and rating from Shopaholic to extension plugins. Add event \"shopaholic.sorting.get.list\" for custom sorting of products. Add integration with \"Related products for Shopaholic\" and \"Accessories for Shopaholic\" plugins','2019-08-12 10:45:39'),(57,'Lovata.Shopaholic','comment','1.4.1','Update annotations for \"Reviews for Shopaholic\" plugin. Fix $dates array in Product model. Thanks for contribution Alexander Shapoval.','2019-08-12 10:45:39'),(58,'Lovata.Shopaholic','comment','1.5.0','Add integration with \"Search for Shopaholic\",\"Sphinx for Shopaholic\" plugins','2019-08-12 10:45:39'),(59,'Lovata.Shopaholic','comment','1.6.0','Add integration with \"Compare for Shopaholic\"','2019-08-12 10:45:39'),(60,'Lovata.Shopaholic','comment','1.7.0','Added translation into French. Thanks for contribution philmarc.','2019-08-12 10:45:39'),(61,'Lovata.Shopaholic','comment','1.8.0','Add integration with \"Viewed products for Shopaholic\" plugin','2019-08-12 10:45:39'),(62,'Lovata.Shopaholic','script','1.9.0','seeder_price_format.php','2019-08-12 10:45:41'),(63,'Lovata.Shopaholic','comment','1.9.0','Add PriceHelperTrait, TraitCached in models. Add active() method to CategoryCollection class. Move PriceHelper class from Shopaholic plugin to Toolbox plugin. Add new store classes. Refactoring *Store, *Item, *Collection classes. Requires Toolbox plugin version 1.10.0 and later.','2019-08-12 10:45:41'),(64,'Lovata.Shopaholic','script','1.10.0','create_table_additional_categories.php','2019-08-12 10:45:42'),(65,'Lovata.Shopaholic','comment','1.10.0','Adding relation between Product model and additional categories. Adding ability to get list of products by category ID list, by the parent category ID.','2019-08-12 10:45:42'),(66,'Lovata.Shopaholic','comment','1.11.0','Adding getPageUrl() method to ProductItem, BrandItem classes.','2019-08-12 10:45:42'),(67,'Lovata.Shopaholic','comment','1.11.1','Adding \"field.additional_category\" value to lang files. Fixed displaying \"additional categories\" field only for update/preview forms.','2019-08-12 10:45:42'),(68,'Lovata.Shopaholic','comment','1.11.2','Fix work with *Store classes in *Handler classes.','2019-08-12 10:45:42'),(69,'Lovata.Shopaholic','comment','1.11.3','Fix error in ProductCollection class, if product list by category is empty.','2019-08-12 10:45:42'),(70,'Lovata.Shopaholic','comment','1.12.0','Added type returned by methods in AbstractStore * classes','2019-08-12 10:45:42'),(71,'Lovata.Shopaholic','script','1.13.0','create_table_promo_block.php','2019-08-12 10:45:43'),(72,'Lovata.Shopaholic','script','1.13.0','create_table_promo_block_relation.php','2019-08-12 10:45:43'),(73,'Lovata.Shopaholic','comment','1.13.0','Added PromoBlock model. Promo blocks are sections of content that you can place throughout your eCommerce website and advertise products, offers, discounts, campaigns, and other activity. Added PromoBlockData, PromoBlockPage, PromoBlockList components. Added PromoBlockItem, PromoBlockCollection classes.','2019-08-12 10:45:43'),(74,'Lovata.Shopaholic','comment','1.13.1','Added annotations for integration with Coupons for Shopaholic, Discounts for Shopaholic, Campaigns for Shopaholic plugins.','2019-08-12 10:45:43'),(75,'Lovata.Shopaholic','comment','1.14.0','Added \"additional_category\" field to ProductItem class.','2019-08-12 10:45:43'),(76,'Lovata.Shopaholic','comment','1.14.1','Remove vendor folder from plugin.','2019-08-12 10:45:43'),(77,'Lovata.Shopaholic','comment','1.15.0','Added import product, offers, categories, brands from CSV file in backend. Requires Toolbox plugin version 1.18.0 and later','2019-08-12 10:45:44'),(78,'Lovata.Shopaholic','comment','1.16.0','Added block with description about import of product/offer properties from CSV file.','2019-08-12 10:45:44'),(79,'Lovata.Shopaholic','comment','1.16.1','Added annotations of filterByDiscount(), filterByQuantity() methods to OfferCollection class.','2019-08-12 10:45:44'),(80,'Lovata.Shopaholic','comment','1.17.0','Added Japanese language. Thanks for contribution pikanji.','2019-08-12 10:45:44'),(81,'Lovata.Shopaholic','comment','1.18.0','Added German language. Thanks for contribution Gerald.','2019-08-12 10:45:44'),(82,'Lovata.Shopaholic','comment','1.19.0','Added translatable slug in Product, Brand, Category, PromoBlock models.','2019-08-12 10:45:44'),(83,'Lovata.Shopaholic','comment','1.19.1','Fixed permissions for promo block menu item. Thanks for contribution Andreas Kosmowicz.','2019-08-12 10:45:44'),(84,'Lovata.Shopaholic','comment','1.20.0','Added Slovak language. Thanks for contribution vosco88.','2019-08-12 10:45:44'),(85,'Lovata.Shopaholic','script','1.21.0','create_table_taxes.php','2019-08-12 10:45:45'),(86,'Lovata.Shopaholic','script','1.21.0','create_table_tax_category_relation.php','2019-08-12 10:45:45'),(87,'Lovata.Shopaholic','script','1.21.0','create_table_tax_product_relation.php','2019-08-12 10:45:45'),(88,'Lovata.Shopaholic','script','1.21.0','create_table_tax_country_relation.php','2019-08-12 10:45:45'),(89,'Lovata.Shopaholic','script','1.21.0','create_table_tax_state_relation.php','2019-08-12 10:45:46'),(90,'Lovata.Shopaholic','script','1.21.0','create_table_currency.php','2019-08-12 10:45:46'),(91,'Lovata.Shopaholic','script','1.21.0','seeder_create_default_currency.php','2019-08-12 10:45:47'),(92,'Lovata.Shopaholic','script','1.21.0','create_table_price_types.php','2019-08-12 10:45:47'),(93,'Lovata.Shopaholic','script','1.21.0','create_table_prices.php','2019-08-12 10:45:47'),(94,'Lovata.Shopaholic','script','1.21.0','update_table_users_add_currency_field.php','2019-08-12 10:45:48'),(95,'Lovata.Shopaholic','script','1.21.0','seeder_transfer_offer_prices.php','2019-08-12 10:45:48'),(96,'Lovata.Shopaholic','script','1.21.0','update_table_offers_remove_price_field.php','2019-08-12 10:45:48'),(97,'Lovata.Shopaholic','comment','1.21.0','Added multicurrency. Added taxes. Added price types. Added shopaholic:check.table.integrity artisan command.','2019-08-12 10:45:48'),(98,'Lovata.Shopaholic','comment','1.21.1','Fixed labels for tax settings.','2019-08-12 10:45:48'),(99,'Lovata.Shopaholic','comment','1.21.2','Fix error with saving offer without prices.','2019-08-12 10:45:48'),(100,'Lovata.Shopaholic','comment','1.22.0','Added customizable import from xml file. Thanks to Rolands Zeltins. His donation made this feature available for everyone.','2019-08-12 10:45:48'),(101,'Lovata.Shopaholic','comment','1.22.1','Fixed command shopaholic:import_from_xml.','2019-08-12 10:45:49'),(102,'Lovata.Shopaholic','comment','1.22.2','Added \"deactivate\" fields to config of XmlImportSettings model.','2019-08-12 10:45:49'),(103,'Lovata.Shopaholic','comment','1.22.3','Fixed attaching of children categories to parent category in script of import from XML.','2019-08-12 10:45:49'),(104,'Lovata.Shopaholic','comment','1.22.4','Removed deleted offers from sorting by price.','2019-08-12 10:45:49'),(105,'Lovata.Shopaholic','comment','1.22.5','Fixed bug with deactivating items in import from XML files.','2019-08-12 10:45:49'),(106,'Lovata.OrdersShopaholic','script','1.0.0','table_create_cart.php','2019-08-12 11:02:14'),(107,'Lovata.OrdersShopaholic','script','1.0.0','table_create_cart_element.php','2019-08-12 11:02:14'),(108,'Lovata.OrdersShopaholic','script','1.0.0','table_create_offer_order.php','2019-08-12 11:02:15'),(109,'Lovata.OrdersShopaholic','script','1.0.0','table_create_order.php','2019-08-12 11:02:15'),(110,'Lovata.OrdersShopaholic','script','1.0.0','table_create_payment_method.php','2019-08-12 11:02:16'),(111,'Lovata.OrdersShopaholic','script','1.0.0','table_create_shipping_type.php','2019-08-12 11:02:16'),(112,'Lovata.OrdersShopaholic','script','1.0.0','table_create_status.php','2019-08-12 11:02:16'),(113,'Lovata.OrdersShopaholic','script','1.0.0','seeder_default_status.php','2019-08-12 11:02:17'),(114,'Lovata.OrdersShopaholic','comment','1.0.0','Initialize plugin.','2019-08-12 11:02:17'),(115,'Lovata.OrdersShopaholic','comment','1.0.1','Fix permission tab label in config','2019-08-12 11:02:17'),(116,'Lovata.OrdersShopaholic','comment','1.0.2','Remove php short tags from orders/_price_block.htm','2019-08-12 11:02:17'),(117,'Lovata.OrdersShopaholic','script','1.0.3','seeder_update_order_secret_key.php','2019-08-12 11:02:17'),(118,'Lovata.OrdersShopaholic','comment','1.0.3','Change method for generation secret_key field in Order model','2019-08-12 11:02:18'),(119,'Lovata.OrdersShopaholic','comment','1.0.4','Adding additional cache cleaning for the sorted list of payment methods and shipping types, after the creation of a new element. Requires Toolbox plugin version 1.3.0 and later.','2019-08-12 11:02:18'),(120,'Lovata.OrdersShopaholic','comment','1.0.5','$casts property is replaced with $jsonable property in the Order model','2019-08-12 11:02:18'),(121,'Lovata.OrdersShopaholic','comment','1.1.0','The \"rewrite\" and \"increase\" flags are removed from the method of updating the quantity of items in the cart','2019-08-12 11:02:18'),(122,'Lovata.OrdersShopaholic','script','1.2.0','table_create_addition_properties.php','2019-08-12 11:02:18'),(123,'Lovata.OrdersShopaholic','script','1.2.0','seeder_default_order_properties.php','2019-08-12 11:02:19'),(124,'Lovata.OrdersShopaholic','comment','1.2.0','Add additional properties for Order model. Add settings for validation the email field as required.','2019-08-12 11:02:19'),(125,'Lovata.OrdersShopaholic','comment','1.2.1','Remove php short tags from orders/_price_block.htm','2019-08-12 11:02:20'),(126,'Lovata.OrdersShopaholic','script','1.3.0','table_update_shipping_type_add_price_field.php','2019-08-12 11:02:20'),(127,'Lovata.OrdersShopaholic','comment','1.3.0','Add \"price\" field in ShippingType model','2019-08-12 11:02:20'),(128,'Lovata.OrdersShopaholic','comment','1.3.1','Added check for isNested flag when expanding forms','2019-08-12 11:02:20'),(129,'Lovata.OrdersShopaholic','comment','1.4.0','Add integration with RainLab.User plugin. Added sending emails to the user and managers after the order was created. Add events \"shopaholic.order.created\", \"shopaholic.order.created.user.template.data\", \"shopaholic.order.created.manager.template.data\". Requires Toolbox plugin version 1.7.0 and later.','2019-08-12 11:02:20'),(130,'Lovata.OrdersShopaholic','comment','1.5.0','Update logic for new version of CResult class. Requires Toolbox plugin version 1.9.1 and later.','2019-08-12 11:02:20'),(131,'Lovata.OrdersShopaholic','script','1.6.0','table_update_status_add_is_user_show_field.php','2019-08-12 11:02:20'),(132,'Lovata.OrdersShopaholic','script','1.6.0','table_create_order_positions.php','2019-08-12 11:02:21'),(133,'Lovata.OrdersShopaholic','script','1.6.0','table_create_cart_positions.php','2019-08-12 11:02:22'),(134,'Lovata.OrdersShopaholic','script','1.6.0','table_create_order_position_addition_properties.php','2019-08-12 11:02:22'),(135,'Lovata.OrdersShopaholic','script','1.6.0','table_update_orders_remove_total_price_field.php','2019-08-12 11:02:22'),(136,'Lovata.OrdersShopaholic','comment','1.6.0','Add classes: OrderCollection, OrderPositionCollection, StatusCollection,  OrderItem, OrderPositionItem, StatusItem. Add StatusList component. Adding the ability to create custom properties for order positions. Adding the ability to attach users with orders. Adding the ability to create/update order positions in backend. Add filter order list (backend) by payment method, shipping type, created_at/update_at fields. Add \"hasMany\" relation in User model with Order model. Add \"user_list\" property in User model. Add \"order\" in UserItem class. Refactoring CartProcessor, OrderProcessor classes. Rename classes: CartElementCollection => CartPositionCollection, CartElementItem => CartPositionItem. Requires Toolbox plugin version 1.10.0 and later.','2019-08-12 11:02:22'),(137,'Lovata.OrdersShopaholic','comment','1.6.1','Fix error in OrderPage::get() method.','2019-08-12 11:02:22'),(138,'Lovata.OrdersShopaholic','comment','1.6.2','Fix error in OfferOrderPositionProcessor class.','2019-08-12 11:02:23'),(139,'Lovata.OrdersShopaholic','comment','1.6.3','Fix work with *Store classes in *Handler classes','2019-08-12 11:02:23'),(140,'Lovata.OrdersShopaholic','script','1.6.4','seeder_fix_position_type_value.php','2019-08-12 11:02:23'),(141,'Lovata.OrdersShopaholic','comment','1.6.4','Fix position type default value','2019-08-12 11:02:23'),(142,'Lovata.OrdersShopaholic','script','1.7.0','table_update_payment_method_add_gateway_field.php','2019-08-12 11:02:23'),(143,'Lovata.OrdersShopaholic','script','1.7.0','table_update_orders_add_payment_data_fields.php','2019-08-12 11:02:24'),(144,'Lovata.OrdersShopaholic','comment','1.7.0','Improved integration with payment systems. Adds of shipping price filling from shipping type object, if shipping_price field value from request is empty.','2019-08-12 11:02:24'),(145,'Lovata.OrdersShopaholic','script','1.8.0','table_update_orders_add_payment_token_field.php','2019-08-12 11:02:24'),(146,'Lovata.OrdersShopaholic','comment','1.8.0','Add payment_token field to Order model','2019-08-12 11:02:24'),(147,'Lovata.OrdersShopaholic','comment','1.9.0','Added type returned by methods in AbstractStore * classes.','2019-08-12 11:02:24'),(148,'Lovata.OrdersShopaholic','comment','1.9.1','Adds secret_key field to OrderItem object.','2019-08-12 11:02:24'),(149,'Lovata.OrdersShopaholic','comment','1.10.0','Add Validation trait to Order model.','2019-08-12 11:02:24'),(150,'Lovata.OrdersShopaholic','comment','1.10.1','Remove links on lang file of Buddies plugin.','2019-08-12 11:02:25'),(151,'Lovata.OrdersShopaholic','comment','1.10.2','Fixed labels in ShippingType controller breadcrumbs.','2019-08-12 11:02:25'),(152,'Lovata.OrdersShopaholic','script','1.11.0','table_create_promo_mechanism.php','2019-08-12 11:02:25'),(153,'Lovata.OrdersShopaholic','script','1.11.0','table_create_order_promo_mechanism.php','2019-08-12 11:02:25'),(154,'Lovata.OrdersShopaholic','script','1.11.0','table_create_user_addresses.php','2019-08-12 11:02:26'),(155,'Lovata.OrdersShopaholic','script','1.11.0','seeder_address_order_properties.php','2019-08-12 11:02:31'),(156,'Lovata.OrdersShopaholic','script','1.11.0','table_update_orders_add_currency_field.php','2019-08-12 11:02:31'),(157,'Lovata.OrdersShopaholic','script','1.11.0','table_update_orders_add_manager_id_field.php','2019-08-12 11:02:32'),(158,'Lovata.OrdersShopaholic','script','1.11.0','table_create_tasks.php','2019-08-12 11:02:32'),(159,'Lovata.OrdersShopaholic','comment','1.11.0','Added PromoMechanism model. Added of opportunity to change price of order positions, shipping price, order total price, using promo mechanisms. Added user addresses. Added tasks with relation with orders, users.','2019-08-12 11:02:32'),(160,'Lovata.OrdersShopaholic','comment','1.11.1','Added annotations for integration with Coupons for Shopaholic, Discounts for Shopaholic, Campaigns for Shopaholic plugins.','2019-08-12 11:02:32'),(161,'Lovata.OrdersShopaholic','comment','1.11.2','Fixed the logic of getting custom field values of the saved user address when creating an order.','2019-08-12 11:02:32'),(162,'Lovata.OrdersShopaholic','comment','1.11.3','Fixed update of price data before sending an order to the payment gateway','2019-08-12 11:02:32'),(163,'Lovata.OrdersShopaholic','comment','1.11.4','Fixed creation of an order position via add() method.','2019-08-12 11:02:33'),(164,'Lovata.OrdersShopaholic','comment','1.12.0','Added supported types of order properties: number, rich editor, single checkbox, switch, balloon selector, tag list, radio.','2019-08-12 11:02:33'),(165,'Lovata.OrdersShopaholic','comment','1.12.1','Fixed logic for calculating old total price of order position without discounts.','2019-08-12 11:02:33'),(166,'Lovata.OrdersShopaholic','comment','1.13.0','Added Japanese language. Thanks for contribution pikanji.','2019-08-12 11:02:33'),(167,'Lovata.OrdersShopaholic','comment','1.14.0','Added getCurrency() method in Cart component. Improved parameter generation for redirecting to order page in MakeOrder component. Added shipping_type_id parameter processing in onAdd, onUpdate, onRemove methods (Cart component)','2019-08-12 11:02:33'),(168,'Lovata.OrdersShopaholic','script','1.14.1','table_update_tasks_change_description_type.php','2019-08-12 11:02:34'),(169,'Lovata.OrdersShopaholic','comment','1.14.1','Changed type of \"description\" field in task table.','2019-08-12 11:02:34'),(170,'Lovata.OrdersShopaholic','comment','1.14.2','Fixed link to cancel button in backend (OrderPosition controller)','2019-08-12 11:02:34'),(171,'Lovata.OrdersShopaholic','comment','1.14.3','Fixed OrderProcessor::EVENT_GET_SHIPPING_PRICE event. Thanks for contribution GitLog.','2019-08-12 11:02:34'),(172,'Lovata.OrdersShopaholic','comment','1.15.0','Added German language. Thanks for contribution Gerald.','2019-08-12 11:02:34'),(173,'Lovata.OrdersShopaholic','comment','1.16.0','Added checking addresses for uniqueness before creating a new user address or order.','2019-08-12 11:02:34'),(174,'Lovata.OrdersShopaholic','comment','1.17.0','Added shopaholic.shipping_type.get_price event. The event allows you to dynamically change the shipping price.','2019-08-12 11:02:34'),(175,'Lovata.OrdersShopaholic','comment','1.18.0','Added calculate_per_unit setting parameter in PromoMechanism model.','2019-08-12 11:02:34'),(176,'Lovata.OrdersShopaholic','script','1.19.0','table_update_taxes_add_applied_to_shipping_price.php','2019-08-12 11:02:34'),(177,'Lovata.OrdersShopaholic','script','1.19.0','table_update_order_positions_add_tax_percent_field.php','2019-08-12 11:02:35'),(178,'Lovata.OrdersShopaholic','script','1.19.0','table_update_orders_add_currency_id_field.php','2019-08-12 11:02:35'),(179,'Lovata.OrdersShopaholic','script','1.19.0','table_update_orders_add_shipping_tax_percent_field.php','2019-08-12 11:02:35'),(180,'Lovata.OrdersShopaholic','comment','1.19.0','!!! Added Taxes. Added multicyrrency. Requires Shopaholic plugin version 1.21.0 and later.','2019-08-12 11:02:35'),(181,'Lovata.OrdersShopaholic','script','1.20.0','table_update_shipping_types_add_method_and_property_fields.php','2019-08-12 11:02:36'),(182,'Lovata.OrdersShopaholic','script','1.20.0','table_update_carts_add_fields.php','2019-08-12 11:02:36'),(183,'Lovata.OrdersShopaholic','script','1.20.0','table_create_shipping_restrictions_table.php','2019-08-12 11:02:36'),(184,'Lovata.OrdersShopaholic','script','1.20.0','table_create_shipping_restrictions_link_table.php','2019-08-12 11:02:37'),(185,'Lovata.OrdersShopaholic','comment','1.20.0','Added ability to add multiple identical offers, but with different set of properties. Added ability to delete cart positions by ID. Added ability to create integration with API of delivery services. Added property fields in ShippingType model. Added ability to create restrictions for shipping types.  Added restrictions of shipping types by position total price. Added email, user_data, shipping_address, billing_address, shipping_type_id, payment_method_id, property fields in Cart model. Thanks for contribution Tsagan Noniev and Rubium Web.','2019-08-12 11:02:37'),(186,'Lovata.OrdersShopaholic','script','1.21.0','table_update_cart_positions_add_deleted_field.php','2019-08-12 11:02:37'),(187,'Lovata.OrdersShopaholic','comment','1.21.0','Added onRestore method to Cart component.','2019-08-12 11:02:37'),(188,'Lovata.OrdersShopaholic','script','1.22.0','table_create_payment_restrictions_table.php','2019-08-12 11:02:37'),(189,'Lovata.OrdersShopaholic','script','1.22.0','table_create_payment_restrictions_link_table.php','2019-08-12 11:02:38'),(190,'Lovata.OrdersShopaholic','comment','1.22.0','Added ability to create restrictions for payment methods. Added restrictions of payment methods by shipping type. Thanks for contribution Tsagan Noniev and Rubium Web.','2019-08-12 11:02:38'),(191,'Lovata.OrdersShopaholic','script','1.22.1','table_update_user_addresses_change_postcode.php','2019-08-12 11:02:38'),(192,'Lovata.OrdersShopaholic','comment','1.22.1','Changed type of postcode field from int to string.','2019-08-12 11:02:38'),(193,'RainLab.User','script','1.0.1','create_users_table.php','2019-08-12 11:10:54'),(194,'RainLab.User','script','1.0.1','create_throttle_table.php','2019-08-12 11:10:55'),(195,'RainLab.User','comment','1.0.1','Initialize plugin.','2019-08-12 11:10:55'),(196,'RainLab.User','comment','1.0.2','Seed tables.','2019-08-12 11:10:55'),(197,'RainLab.User','comment','1.0.3','Translated hard-coded text to language strings.','2019-08-12 11:10:55'),(198,'RainLab.User','comment','1.0.4','Improvements to user-interface for Location manager.','2019-08-12 11:10:55'),(199,'RainLab.User','comment','1.0.5','Added contact details for users.','2019-08-12 11:10:55'),(200,'RainLab.User','script','1.0.6','create_mail_blockers_table.php','2019-08-12 11:10:56'),(201,'RainLab.User','comment','1.0.6','Added Mail Blocker utility so users can block specific mail templates.','2019-08-12 11:10:56'),(202,'RainLab.User','comment','1.0.7','Add back-end Settings page.','2019-08-12 11:10:56'),(203,'RainLab.User','comment','1.0.8','Updated the Settings page.','2019-08-12 11:10:56'),(204,'RainLab.User','comment','1.0.9','Adds new welcome mail message for users and administrators.','2019-08-12 11:10:56'),(205,'RainLab.User','comment','1.0.10','Adds administrator-only activation mode.','2019-08-12 11:10:56'),(206,'RainLab.User','script','1.0.11','users_add_login_column.php','2019-08-12 11:10:56'),(207,'RainLab.User','comment','1.0.11','Users now have an optional login field that defaults to the email field.','2019-08-12 11:10:56'),(208,'RainLab.User','script','1.0.12','users_rename_login_to_username.php','2019-08-12 11:10:57'),(209,'RainLab.User','comment','1.0.12','Create a dedicated setting for choosing the login mode.','2019-08-12 11:10:57'),(210,'RainLab.User','comment','1.0.13','Minor fix to the Account sign in logic.','2019-08-12 11:10:57'),(211,'RainLab.User','comment','1.0.14','Minor improvements to the code.','2019-08-12 11:10:57'),(212,'RainLab.User','script','1.0.15','users_add_surname.php','2019-08-12 11:10:57'),(213,'RainLab.User','comment','1.0.15','Adds last name column to users table (surname).','2019-08-12 11:10:57'),(214,'RainLab.User','comment','1.0.16','Require permissions for settings page too.','2019-08-12 11:10:58'),(215,'RainLab.User','comment','1.1.0','!!! Profile fields and Locations have been removed.','2019-08-12 11:10:58'),(216,'RainLab.User','script','1.1.1','create_user_groups_table.php','2019-08-12 11:10:58'),(217,'RainLab.User','script','1.1.1','seed_user_groups_table.php','2019-08-12 11:10:59'),(218,'RainLab.User','comment','1.1.1','Users can now be added to groups.','2019-08-12 11:10:59'),(219,'RainLab.User','comment','1.1.2','A raw URL can now be passed as the redirect property in the Account component.','2019-08-12 11:10:59'),(220,'RainLab.User','comment','1.1.3','Adds a super user flag to the users table, reserved for future use.','2019-08-12 11:10:59'),(221,'RainLab.User','comment','1.1.4','User list can be filtered by the group they belong to.','2019-08-12 11:10:59'),(222,'RainLab.User','comment','1.1.5','Adds a new permission to hide the User settings menu item.','2019-08-12 11:10:59'),(223,'RainLab.User','script','1.2.0','users_add_deleted_at.php','2019-08-12 11:10:59'),(224,'RainLab.User','comment','1.2.0','Users can now deactivate their own accounts.','2019-08-12 11:10:59'),(225,'RainLab.User','comment','1.2.1','New feature for checking if a user is recently active/online.','2019-08-12 11:10:59'),(226,'RainLab.User','comment','1.2.2','Add bulk action button to user list.','2019-08-12 11:10:59'),(227,'RainLab.User','comment','1.2.3','Included some descriptive paragraphs in the Reset Password component markup.','2019-08-12 11:10:59'),(228,'RainLab.User','comment','1.2.4','Added a checkbox for blocking all mail sent to the user.','2019-08-12 11:11:00'),(229,'RainLab.User','script','1.2.5','update_timestamp_nullable.php','2019-08-12 11:11:00'),(230,'RainLab.User','comment','1.2.5','Database maintenance. Updated all timestamp columns to be nullable.','2019-08-12 11:11:00'),(231,'RainLab.User','script','1.2.6','users_add_last_seen.php','2019-08-12 11:11:01'),(232,'RainLab.User','comment','1.2.6','Add a dedicated last seen column for users.','2019-08-12 11:11:01'),(233,'RainLab.User','comment','1.2.7','Minor fix to user timestamp attributes.','2019-08-12 11:11:01'),(234,'RainLab.User','comment','1.2.8','Add date range filter to users list. Introduced a logout event.','2019-08-12 11:11:01'),(235,'RainLab.User','comment','1.2.9','Add invitation mail for new accounts created in the back-end.','2019-08-12 11:11:01'),(236,'RainLab.User','script','1.3.0','users_add_guest_flag.php','2019-08-12 11:11:01'),(237,'RainLab.User','script','1.3.0','users_add_superuser_flag.php','2019-08-12 11:11:01'),(238,'RainLab.User','comment','1.3.0','Introduced guest user accounts.','2019-08-12 11:11:01'),(239,'RainLab.User','comment','1.3.1','User notification variables can now be extended.','2019-08-12 11:11:01'),(240,'RainLab.User','comment','1.3.2','Minor fix to the Auth::register method.','2019-08-12 11:11:02'),(241,'RainLab.User','comment','1.3.3','Allow prevention of concurrent user sessions via the user settings.','2019-08-12 11:11:02'),(242,'RainLab.User','comment','1.3.4','Added force secure protocol property to the account component.','2019-08-12 11:11:02'),(243,'RainLab.User','comment','1.4.0','!!! The Notifications tab in User settings has been removed.','2019-08-12 11:11:02'),(244,'RainLab.User','comment','1.4.1','Added support for user impersonation.','2019-08-12 11:11:02'),(245,'RainLab.User','comment','1.4.2','Fixes security bug in Password Reset component.','2019-08-12 11:11:02'),(246,'RainLab.User','comment','1.4.3','Fixes session handling for AJAX requests.','2019-08-12 11:11:02'),(247,'RainLab.User','comment','1.4.4','Fixes bug where impersonation touches the last seen timestamp.','2019-08-12 11:11:02'),(248,'RainLab.User','comment','1.4.5','Added token fallback process to Account / Reset Password components when parameter is missing.','2019-08-12 11:11:02'),(249,'RainLab.User','comment','1.4.6','Fixes Auth::register method signature mismatch with core OctoberCMS Auth library','2019-08-12 11:11:02'),(250,'RainLab.User','comment','1.4.7','Fixes redirect bug in Account component / Update translations and separate user and group management.','2019-08-12 11:11:03'),(251,'RainLab.User','comment','1.4.8','Fixes a bug where calling MailBlocker::removeBlock could remove all mail blocks for the user.','2019-08-12 11:11:03'),(252,'RainLab.User','comment','1.5.0','!!! Required password length is now a minimum of 8 characters. Previous passwords will not be affected until the next password change.','2019-08-12 11:11:03'),(253,'RainLab.Pages','comment','1.0.1','Implemented the static pages management and the Static Page component.','2019-08-12 15:24:34'),(254,'RainLab.Pages','comment','1.0.2','Fixed the page preview URL.','2019-08-12 15:24:35'),(255,'RainLab.Pages','comment','1.0.3','Implemented menus.','2019-08-12 15:24:35'),(256,'RainLab.Pages','comment','1.0.4','Implemented the content block management and placeholder support.','2019-08-12 15:24:35'),(257,'RainLab.Pages','comment','1.0.5','Added support for the Sitemap plugin.','2019-08-12 15:24:35'),(258,'RainLab.Pages','comment','1.0.6','Minor updates to the internal API.','2019-08-12 15:24:35'),(259,'RainLab.Pages','comment','1.0.7','Added the Snippets feature.','2019-08-12 15:24:35'),(260,'RainLab.Pages','comment','1.0.8','Minor improvements to the code.','2019-08-12 15:24:35'),(261,'RainLab.Pages','comment','1.0.9','Fixes issue where Snippet tab is missing from the Partials form.','2019-08-12 15:24:35'),(262,'RainLab.Pages','comment','1.0.10','Add translations for various locales.','2019-08-12 15:24:35'),(263,'RainLab.Pages','comment','1.0.11','Fixes issue where placeholders tabs were missing from Page form.','2019-08-12 15:24:35'),(264,'RainLab.Pages','comment','1.0.12','Implement Media Manager support.','2019-08-12 15:24:36'),(265,'RainLab.Pages','script','1.1.0','snippets_rename_viewbag_properties.php','2019-08-12 15:24:36'),(266,'RainLab.Pages','comment','1.1.0','Adds meta title and description to pages. Adds |staticPage filter.','2019-08-12 15:24:36'),(267,'RainLab.Pages','comment','1.1.1','Add support for Syntax Fields.','2019-08-12 15:24:36'),(268,'RainLab.Pages','comment','1.1.2','Static Breadcrumbs component now respects the hide from navigation setting.','2019-08-12 15:24:36'),(269,'RainLab.Pages','comment','1.1.3','Minor back-end styling fix.','2019-08-12 15:24:36'),(270,'RainLab.Pages','comment','1.1.4','Minor fix to the StaticPage component API.','2019-08-12 15:24:36'),(271,'RainLab.Pages','comment','1.1.5','Fixes bug when using syntax fields.','2019-08-12 15:24:37'),(272,'RainLab.Pages','comment','1.1.6','Minor styling fix to the back-end UI.','2019-08-12 15:24:37'),(273,'RainLab.Pages','comment','1.1.7','Improved menu item form to include CSS class, open in a new window and hidden flag.','2019-08-12 15:24:37'),(274,'RainLab.Pages','comment','1.1.8','Improved the output of snippet partials when saved.','2019-08-12 15:24:37'),(275,'RainLab.Pages','comment','1.1.9','Minor update to snippet inspector internal API.','2019-08-12 15:24:37'),(276,'RainLab.Pages','comment','1.1.10','Fixes a bug where selecting a layout causes permanent unsaved changes.','2019-08-12 15:24:37'),(277,'RainLab.Pages','comment','1.1.11','Add support for repeater syntax field.','2019-08-12 15:24:37'),(278,'RainLab.Pages','comment','1.2.0','Added support for translations, UI updates.','2019-08-12 15:24:37'),(279,'RainLab.Pages','comment','1.2.1','Use nice titles when listing the content files.','2019-08-12 15:24:37'),(280,'RainLab.Pages','comment','1.2.2','Minor styling update.','2019-08-12 15:24:37'),(281,'RainLab.Pages','comment','1.2.3','Snippets can now be moved by dragging them.','2019-08-12 15:24:38'),(282,'RainLab.Pages','comment','1.2.4','Fixes a bug where the cursor is misplaced when editing text files.','2019-08-12 15:24:38'),(283,'RainLab.Pages','comment','1.2.5','Fixes a bug where the parent page is lost upon changing a page layout.','2019-08-12 15:24:38'),(284,'RainLab.Pages','comment','1.2.6','Shared view variables are now passed to static pages.','2019-08-12 15:24:38'),(285,'RainLab.Pages','comment','1.2.7','Fixes issue with duplicating properties when adding multiple snippets on the same page.','2019-08-12 15:24:38'),(286,'RainLab.Pages','comment','1.2.8','Fixes a bug where creating a content block without extension doesn\'t save the contents to file.','2019-08-12 15:24:38'),(287,'RainLab.Pages','comment','1.2.9','Add conditional support for translating page URLs.','2019-08-12 15:24:38'),(288,'RainLab.Pages','comment','1.2.10','Streamline generation of URLs to use the new Cms::url helper.','2019-08-12 15:24:38'),(289,'RainLab.Pages','comment','1.2.11','Implements repeater usage with translate plugin.','2019-08-12 15:24:38'),(290,'RainLab.Pages','comment','1.2.12','Fixes minor issue when using snippets and switching the application locale.','2019-08-12 15:24:39'),(291,'RainLab.Pages','comment','1.2.13','Fixes bug when AJAX is used on a page that does not yet exist.','2019-08-12 15:24:39'),(292,'RainLab.Pages','comment','1.2.14','Add theme logging support for changes made to menus.','2019-08-12 15:24:39'),(293,'RainLab.Pages','comment','1.2.15','Back-end navigation sort order updated.','2019-08-12 15:24:39'),(294,'RainLab.Pages','comment','1.2.16','Fixes a bug when saving a template that has been modified outside of the CMS (mtime mismatch).','2019-08-12 15:24:39'),(295,'RainLab.Pages','comment','1.2.17','Changes locations of custom fields to secondary tabs instead of the primary Settings area. New menu search ability on adding menu items','2019-08-12 15:24:39'),(296,'RainLab.Pages','comment','1.2.18','Fixes cache-invalidation issues when RainLab.Translate is not installed. Added Greek & Simplified Chinese translations. Removed deprecated calls. Allowed saving HTML in snippet properties. Added support for the MediaFinder in menu items.','2019-08-12 15:24:39'),(297,'RainLab.Pages','comment','1.2.19','Catch exception with corrupted menu file.','2019-08-12 15:24:39'),(298,'RainLab.Pages','comment','1.2.20','StaticMenu component now exposes menuName property; added pages.menu.referencesGenerated event.','2019-08-12 15:24:39'),(299,'RainLab.Pages','comment','1.2.21','Fixes a bug where last Static Menu item cannot be deleted. Improved Persian, Slovak and Turkish translations.','2019-08-12 15:24:39');
/*!40000 ALTER TABLE `system_plugin_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_plugin_versions`
--

DROP TABLE IF EXISTS `system_plugin_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_plugin_versions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_frozen` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `system_plugin_versions_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_plugin_versions`
--

LOCK TABLES `system_plugin_versions` WRITE;
/*!40000 ALTER TABLE `system_plugin_versions` DISABLE KEYS */;
INSERT INTO `system_plugin_versions` (`id`, `code`, `version`, `created_at`, `is_disabled`, `is_frozen`) VALUES (1,'October.Demo','1.0.1','2019-08-12 10:40:11',0,0),(2,'Lovata.Toolbox','1.25.3','2019-08-12 10:45:35',0,0),(3,'Lovata.Shopaholic','1.22.5','2019-08-12 10:45:49',0,0),(4,'Lovata.OrdersShopaholic','1.22.1','2019-08-12 11:02:39',0,0),(5,'RainLab.User','1.5.0','2019-08-12 11:11:03',0,0),(6,'RainLab.Pages','1.2.21','2019-08-12 15:24:40',0,0);
/*!40000 ALTER TABLE `system_plugin_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_request_logs`
--

DROP TABLE IF EXISTS `system_request_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_request_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_request_logs`
--

LOCK TABLES `system_request_logs` WRITE;
/*!40000 ALTER TABLE `system_request_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_request_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_revisions`
--

DROP TABLE IF EXISTS `system_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_revisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cast` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  KEY `system_revisions_user_id_index` (`user_id`),
  KEY `system_revisions_field_index` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_revisions`
--

LOCK TABLES `system_revisions` WRITE;
/*!40000 ALTER TABLE `system_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_settings_item_index` (`item`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` (`id`, `item`, `value`) VALUES (1,'lovata_toolbox_settings','{\"decimals\":null,\"dec_point\":null,\"thousands_sep\":null}');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_groups_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` (`id`, `name`, `code`, `description`, `created_at`, `updated_at`) VALUES (1,'Guest','guest','Default group for guest users.','2019-08-12 11:10:58','2019-08-12 11:10:58'),(2,'Registered','registered','Default group for registered users.','2019-08-12 11:10:58','2019-08-12 11:10:58');
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_throttle`
--

DROP TABLE IF EXISTS `user_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_throttle_user_id_index` (`user_id`),
  KEY `user_throttle_ip_address_index` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_throttle`
--

LOCK TABLES `user_throttle` WRITE;
/*!40000 ALTER TABLE `user_throttle` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_activated` tinyint(1) NOT NULL DEFAULT 0,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT 0,
  `is_superuser` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_login_unique` (`username`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`),
  KEY `users_login_index` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`user_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'outlet'
--

--
-- Dumping routines for database 'outlet'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-13 17:54:19
